To play Ricky Illusion use level select, it is in Marble Zone's slot.

To play Laundry Zone go to the Laundry Zone rom (of course) and select Labyrinth Zone. 

I encourage you to use debug to see the entire level and get past incomplete paths. 