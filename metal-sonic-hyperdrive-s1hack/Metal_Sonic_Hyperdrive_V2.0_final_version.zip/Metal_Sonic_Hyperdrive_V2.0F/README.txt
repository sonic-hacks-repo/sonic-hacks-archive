Metal Sonic Hyperdrive by Darkon360


Story [METAL]:
One Day, after the defeat of Dr'Eggman by the hands of Sonic. Eggman decided to build a Power Armor sult based off EggRobo and travel to Mobius to capture Sonic and Tails by sending them into a Cosmic portal to trap them, but luckily, Tails escaped. he knew that Sonic is missing and he decided to sneak into Eggman's HQ and grab the parts of Eggman's robots and pieces. Tails later go to his home in the Mystic Ruins and created a new robot, based off Metal Sonic classic model, Codename: METAL. with the ability to feel and behave almost exactly like Sonic, with a special move to directly Jumpdash in any direction, and Walljump through unreachable places. Tails was able to track Eggman to where hes heading by using his Radar, so Tails send Metal Sonic to Resort Isle, where Eggman was heading to. in hopes to find Sonic and Destory Dr'Eggman once and for all.

Eggman later decided to create a mystic portal into other worlds to make his Egg Empire bigger then before,
sending his robots to Kirby, Somari, and Darkon's Worlds attempting to destroy everything in its Path.
the madness has just begun. 


Story [DARKON]:
After defeating Zen, saving the world from nuclear war, and winning the ultimate prize and grand champion.
Darkon saw a portal of Eggman's robots falling from the sky, 
causing mass destruction through the city. Darkon and few of his Friends decided to Kill them all, then Darkon realise the portal was about to close, he jumped through the portal and 
headed into Resort Isle. Darkon don't know where hes at so he decided to go forward and hunt the person whos responsible of sending the robots.


Story [KIRBY]:
Kirby was bored and fell alsleep after eating too much Rare Candys, until he heard a portal coming from the sky, a rain of Eggman's robots appear, Kirby knew hes in big trouble. until one of Eggman's Badniks pushed Kirby into the portal. later, Kirby woke up and he is in Resort Isle. Kirby don't know what is going on so he decided to explore the place and find the one whos causing a rain of robots in his home world.


Story [SOMARI]:
A NES Cart of Somari was found by the hands of Eggman's Badniks. after attempting to insert it into the NES Console, Somari poped out of the screen, and killed one of the Badniks, not knowing that the NES Console is corrupted with unknown magic. Somari was later trapped by one of Eggman's robots and send him back to prison in Resort Isle, Somari luckliy escaped the prison cell and off to get his revenge.


Story [SONIC]:
Sonic was captured by Eggman in the sky, he broke free and attempts countless Homing Attacks on Eggman but 
it won't work, due to Eggman's new battle armor. Eggman later smashed away Sonic into the air and escapes.
Sonic landed on Resort Isle, he woked up and realise hes in a New World, Sonic decided to search for Eggman and put a stop to him and his mess for good. 
 



Hints:

How to get the Chaos Emeralds?: 
After grabbing 50 or more Rings into the Signpost, Jump into the Giant Ring, you will automaticity gain 1 Emerald. the max is 6 Emeralds. this is also useful for getting the secret ending.

How to become SUPER Sonic?:
Get all Chaos Emeralds and press Up + A in mid air to transform, only METAL can become Super.
