You're lucky to be playing this awesome adventure! It's the best Sonic game there is, guarantee!
The description is in the hacking contest form if you want to read it, otherwise just play the game!
Have fun and only die in your own game! Otherwise you won't be regenerated. :V