Sonic 1 FM Source Code
======================
This contains the full source code for my hack "Sonic 1 FM", including MIDIs, VGMs and custom tools I wrote and used when I made this hack.
 
Everything should be well-documented or easy to understand. S1SMS_Info.txt contains a list of all RAM values. So if some offsets are unclear, that list might help.
 
 
The .bk2 files are movies for the BizHawk. They might not give the exact same results as with the versions they were originally recorded with, because the game is quite laggy, and BizHawk required a few ROM patches to lower the PSG volume.
SBZ2.bk2 works with built_shc03.sms and requires you to set RAM 123E = 10 at the title screen. It desyncs after a while though.
S1_GHZ.bk2 should work with built_shc05.sms
 
 
Development Story
-----------------
In 2011, I began to make OPLL (YM2413) versions of songs of the songs from Sonic 1 SMS and posted VGMs of them in the SMSPower! Forums. http://www.smspower.org/forums/13111-Sonic1OSTOPLLRemake
I did them in a way similar to how Phantasy Star upgraded the PSG songs to use the FM chip. That means I did not use all extra harmonies. Instead, each PSG track plays on two FM channels with different instruments (and sometimes at different octaves). Although that's a pretty simple way of doing FM versions, that worked pretty well.
Until the end of 2011, I did most major BGMs, even though I didn't release the OPLL version of Green Hill Zone. The remaining songs (like Marble Zone) were done within the 2 weeks I effectively worked on the hack.
 
In late 2013, I disassembled the sound driver for Kroc, who was doing a complete disassembly of Sonic 1 and discovered the unreferenced and hidden Marble Zone track while investigating the game.
S1SMS_snddrv_disasm_final.7z is the final version of the sound driver disassembly I sent to him.
 
Later in July 2014, the actual development on Sonic 1 FM started. It began on 11 July with a small tool (S1_Cmds) that was supposed to be a very customizable version of smps2asm. The tool worked well and although I never got so far that the customization of the file header worked, it was enough for the format used by Sonic 1.
Today, I can't remember when I really got the idea for Sonic 1 FM, but the Sonic Hacking Contest 2014 was close and I wanted to see if I would be fast enough to complete the hack within 3 weeks.
 
On 20 July, I began working on the sound driver itself. But before I could add code to the driver, I had to free some ROM space, because the 16 KB ROM bank the game reserves for sound driver + data had only about 200 bytes left.
So I started a small tool (S1_Conv.c) that converted the sound sequences to a custom format that is smaller. (The note format was initially made for another sound driver I wrote and is inspired by the AKAO format used by Final Fantasy SNES/PSX games.) The original sequence format used 2 full bytes for every note, and the 5-byte ADSR envelopes were part of the sequence data too. The new format uses between 1 and 2 bytes per note. Drum tracks use close to 1.0 bytes per note in average. The tool also splits the instruments into a separate file, so ADSR envelopes used by multiple tracks would be stored only once.
I probably could have just removed Marble Zone; but compared to optimizing the sound format, that would have been a pretty dumb solution.
 
Working on the sound driver was pretty fun. It started with simple things like moving bytes around to optimize RAM usage. (There is no reason to keep a copy of 5 bytes of modulation data if you can just store a 2-byte reference, for example.) Basic FM support was working on 22 July, but it didn't sound great. All tracks used the same instrument, because the PSG has only "envelopes" that need to be mapped to FM instruments manually and vibrato effects were odd due to differences in the frequency scales between FM and PSG.
With working FM support, I could start working on the actual tracks. I started with Sky Base Act 2, because it matched my mood in that moment. As part of the new sound format, I could give different values for FM and PSG channels for various commands, including instruments, volume and modulation. And especially the latter was something where Sky Base 2 was a good test case.
Song editing itself was done with ASM'ed songs. This way it was not only easy to move things around and optimize stuff, but I could also make minor changes to the sound format by editing the Format_inc.asm file.
While editing the songs, I looked at the VGM files I made to get the correct instrument and volume values.
Naming the edited songs "_2.asm" helped with keeping track of the progress, btw. I also kept the original ASM files to be able to compare "before" and "after", in case I made mistakes while heavily optimizing the song data.
 
When I started the project, I figured that I'd have to do 1-2 tracks each day to get the whole soundtrack done within 2 weeks. The initial build I submitted to the SHC on the 30 July (built_shc03.sms) only included the songs I had finished on 25 July, btw. (I didn't want to show anything spectacular in case I wouldn't make it in time.) But in the end I had time left for additional features.
 
And these are the easter eggs. Oh, I had so much fun adding them. The first one was the Green Hill song with longer intro. I need to thank Kroc here for his full disassembly of Sonic 1, because it made it easier to find the routine that is responsible for Sonic's death. It also proved very useful for finding unused code that I could overwrite.
 
All important things were finished at the evening of 5 August, and the deadline was the night between the 6th and 7th. So what do you do with the remaining day? You add more easter eggs!
A very trivial one was the variation of the boss music for the final boss. The original game actually played the boss tune with another ID already (IDs 0B, 0C and 0D pointed all to the same song), so all I had to do to make it play was a pointer change in the song pointer list.
The easter egg that I actually did the last day was the music for the Game Over screen. At first I ported the "Game Over" and the "Continue" song from the Mega Drive version of Sonic 1. I did that by using smps2mid first to get a MIDI of the songs, then used another small tool to convert those into ASM'ed songs. Those were edited in a way similar to what I did with the other songs. But unlike the other songs, they use the FM channels to play fuller chords. The Continue song ended up being unused though when I decided that it would be nice to play a short version of Game Over song when you have no continues left. The long one is played while the game waits for the player to confirm using another Continue.
 
An additional extra that didn't make it into the SHC version of the game is an OPLL version of the "Sonic Retro Theme" I made on 8 August. That was after the update deadline and there wouldn't have been enough space for it in the ROM anyway. This song took quite a long way. It is the Space Harrier Main Theme, that was shortened into a jingle for the game "Rent A Hero". It was then ported into various Sonic hacks made by members of the Sonic Retro community. I logged the version used in Sonic 1 Megamix v3 into a VGM, converted it using vgm2mid and made an XG remix out of that. (SRetroXG.mid) This MIDI was used in my JRPG music mod for Sonic & Knuckles PC Collection. Finally, it was also used to make the OPLL version.
An FM port of Green Hills Zone from Sonic 2 SMS/GG was planned, but I never made it because I never finished the S1_Conv tool.
 
 
Compiling
---------
Everything related to the ROM can be found in the "NewFormat"-folder.
In order to compile the ROM, you need a copy of the original Sonic the Hedgehog (SMS) ROM.
It must be placed in that folder with the name "Sonic1.sms".
Then you can just double-click build.bat.
 
You can compile the tools by either using the Visual Studio 2010 project files or by compiling them by hand with MinGW/GCC.
S1_Conv.c is stand alone.
S1_Cmds.c also requires ini_lib.c to be compiled and linked in.
 
 
Enjoy!
Valley Bell
