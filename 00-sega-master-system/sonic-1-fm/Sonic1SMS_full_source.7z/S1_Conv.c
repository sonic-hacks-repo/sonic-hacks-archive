#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include "stdtype.h"
#include <windows.h>


typedef struct _instrument_data
{
	UINT8 Data[8];
} INS_DATA;


UINT8 LoadFileData(const char* FileName);
UINT8 SaveFileData(const char* FileName);
void ExtractData(UINT16 StartPos, UINT8 SongCnt, const char* BaseStr, UINT8 StepSize);
void ConvertMusicData(UINT8* InsCount, INS_DATA* InsLib);
void ConvertSFXData(UINT8* InsCount, INS_DATA* InsLib);
static void ConvertTrackData(UINT16 InPos, UINT16* OutPosA, UINT8* InsCount, INS_DATA* InsLib);
static UINT16 ReadLE16(const UINT8* Data);
static void WriteLE16(UINT8* Buffer, UINT16 Value);


UINT32 InSize;
UINT8* InData;
UINT32 OutSize;
UINT8* OutData;
UINT16* InDstPtrs;

#define FILE_PATH	"D:/VStudio-Programme/ASM68k/SoundDrvs/Sonic1SMS/"
int main(int argc, char* argv[])
{
	UINT8 RetVal;
	HANDLE hFndFile;
	WIN32_FIND_DATA FndData;
	char FileName[MAX_PATH];
	UINT8 InsCount;
	INS_DATA InsLib[0x80];
	
#if 0
	RetVal = LoadFileData(FILE_PATH "../S1SMSdump.bin");
	if (RetVal)
		return 1;
	
	//ExtractData(0x4716, 0x15, "Mus", 0x02);
	ExtractData(0x4740, 0x24, "SFX", 0x04);
	free(InData);
#else
	InsCount = 0x00;
	memset(InsLib, 0x00, sizeof(InsLib));
	
	hFndFile = FindFirstFile(FILE_PATH "/Mus*.bin", &FndData);
	if (hFndFile == INVALID_HANDLE_VALUE)
		return 2;
	
	do
	{
		printf("%s: ", FndData.cFileName);
		sprintf(FileName, "%s%s", FILE_PATH, FndData.cFileName);
		RetVal = LoadFileData(FileName);
		if (RetVal)
			return 1;
		
		ConvertMusicData(&InsCount, InsLib);
		printf("%u -> %u bytes (%.2f%%)\n", InSize, OutSize, OutSize * 100.0f / InSize);
		free(InData);	InData = NULL;
		
		sprintf(FileName, "%s%s%s", FILE_PATH, "NewFormat/", FndData.cFileName);
		RetVal = SaveFileData(FileName);
		free(OutData);	OutData = NULL;
	} while(FindNextFile(hFndFile, &FndData));
	FindClose(hFndFile);
	
	printf("Total instruments: 0x%02X\n", InsCount);
	OutSize = InsCount * 8;
	OutData = InsLib[0x00].Data;
	sprintf(FileName, "%s%s%s", FILE_PATH, "NewFormat/", "Mus_InsLib.bin");
	RetVal = SaveFileData(FileName);
	OutData = NULL;
	
	InsCount = 0x00;
	hFndFile = FindFirstFile(FILE_PATH "/SFX*.bin", &FndData);
	if (hFndFile == INVALID_HANDLE_VALUE)
		return 2;
	
	do
	{
		printf("%s: ", FndData.cFileName);
		sprintf(FileName, "%s%s", FILE_PATH, FndData.cFileName);
		RetVal = LoadFileData(FileName);
		if (RetVal)
			return 1;
		
		ConvertSFXData(&InsCount, InsLib);
		printf("%u -> %u bytes (%.2f%%)\n", InSize, OutSize, OutSize * 100.0f / InSize);
		free(InData);	InData = NULL;
		
		sprintf(FileName, "%s%s%s", FILE_PATH, "NewFormat/", FndData.cFileName);
		RetVal = SaveFileData(FileName);
		free(OutData);	OutData = NULL;
	} while(FindNextFile(hFndFile, &FndData));
	FindClose(hFndFile);
	
	printf("Total instruments: 0x%02X\n", InsCount);
	OutSize = InsCount * 8;
	OutData = InsLib[0x00].Data;
	sprintf(FileName, "%s%s%s", FILE_PATH, "NewFormat/", "SFX_InsLib.bin");
	RetVal = SaveFileData(FileName);
	OutData = NULL;
#endif
	
	_getch();
	return 0;
}

UINT8 LoadFileData(const char* FileName)
{
	FILE* hFile;
	
	hFile = fopen(FileName, "rb");
	if (hFile == NULL)
		return 0xFF;
	
	fseek(hFile, 0x00, SEEK_END);
	InSize = ftell(hFile);
	
	fseek(hFile, 0x00, SEEK_SET);
	InData = (UINT8*)malloc(InSize);
	fread(InData, 0x01, InSize, hFile);
	
	fclose(hFile);
	
	return 0x00;
}

UINT8 SaveFileData(const char* FileName)
{
	FILE* hFile;
	
	hFile = fopen(FileName, "wb");
	if (hFile == NULL)
		return 0xFF;
	
	fwrite(OutData, 0x01, OutSize, hFile);
	
	fclose(hFile);
	
	return 0x00;
}

void ExtractData(UINT16 StartPos, UINT8 SongCnt, const char* BaseStr, UINT8 StepSize)
{
	UINT16 SongPos[0x40];
	UINT16 SongLen[0x40];
	char FileName[0x100];
	FILE* hFileOut;
	UINT16 CurPos;
	UINT8 CurSng;
	UINT8 CurSng2;
	
	CurPos = StartPos;
	for (CurSng = 0x00; CurSng <= SongCnt; CurSng ++, CurPos += StepSize)
	{
		SongPos[CurSng] =	(InData[CurPos + 0x00] << 0) |
							(InData[CurPos + 0x01] << 8);
	}
	for (CurSng = 0x00; CurSng < SongCnt; CurSng ++)
	{
		CurPos = 0x7FFF;
		for (CurSng2 = 0x00; CurSng2 <= SongCnt; CurSng2 ++)
		{
			if (SongPos[CurSng2] < CurPos && SongPos[CurSng2] > SongPos[CurSng])
				CurPos = SongPos[CurSng2];
		}
		SongLen[CurSng] = CurPos - SongPos[CurSng];
		
		for (CurSng2 = 0x00; CurSng2 < CurSng; CurSng2 ++)
		{
			if (SongPos[CurSng2] == SongPos[CurSng])
				SongPos[CurSng] = 0x0000;
		}
	}
	for (CurSng = 0x00; CurSng < SongCnt; CurSng ++)
	{
		if (! SongPos[CurSng])
			continue;
		
		sprintf(FileName, "%s%s_%02X.bin", FILE_PATH, BaseStr, CurSng);
		hFileOut = fopen(FileName, "wb");
		if (hFileOut != NULL)
		{
			fwrite(InData + SongPos[CurSng], 0x01, SongLen[CurSng], hFileOut);
			fclose(hFileOut);
		}
	}
	
	return;
}

//#define TICKPQRT_OLD	24
//#define TICKPQRT_NEW	48
#define TICK_FACTOR	2
static const UINT8 DELAY_TBL[0x0D] =
{	192,  96,  48,  24,  12,   6,   3,
	      64,  32,  16,   8,   4,   2};
static UINT16 ConvertNoteLen(UINT8 Ticks)
{
	UINT16 NewTicks;
	UINT8 CurDly;
	
	NewTicks = Ticks * TICK_FACTOR;
	if (NewTicks > 0xFF)
		printf("Large Delay!!!\n");
	
	for (CurDly = 0x00; CurDly < 0x0D; CurDly ++)
	{
		if (DELAY_TBL[CurDly] == NewTicks)
			return CurDly;
	}
	return (NewTicks << 8) | (0x0D << 0);
}

void ConvertMusicData(UINT8* InsCount, INS_DATA* InsLib)
{
	UINT8 CurTrk;
	UINT16 InPos;
	UINT16 OutPos;
	
	InDstPtrs = (UINT16*)malloc(InSize * sizeof(UINT16));
	OutSize = InSize * 4;
	OutData = (UINT8*)malloc(OutSize);
	
	OutPos = 0x0A;
	for (CurTrk = 0x00; CurTrk < 0x04; CurTrk ++)
	{
		InPos = ReadLE16(&InData[CurTrk * 0x02]);
		ConvertTrackData(InPos, &OutPos, InsCount, InsLib);
	}
	/*WriteLE16(&OutData[0x08], OutPos);
	memcpy(&OutData[OutPos], InsLib, 6 * InsCount);
	OutPos += 6 * InsCount;*/
	
	OutSize = OutPos;
	
	// write header pointers
	for (CurTrk = 0x00; CurTrk < 0x04; CurTrk ++)
	{
		InPos = ReadLE16(&InData[CurTrk * 0x02]);
		OutPos = InDstPtrs[InPos];
		WriteLE16(&OutData[CurTrk * 0x02], OutPos);
	}
	InPos = ReadLE16(&InData[CurTrk * 0x02]);
	OutPos = InPos;
	WriteLE16(&OutData[CurTrk * 0x02], OutPos);
	
	return;
}

void ConvertSFXData(UINT8* InsCount, INS_DATA* InsLib)
{
	UINT16 InPos;
	UINT16 OutPos;
	
	InDstPtrs = (UINT16*)malloc(InSize * sizeof(UINT16));
	OutSize = InSize * 4;
	OutData = (UINT8*)malloc(OutSize);
	
	InPos = 0x06;
	OutPos = 0x06;
	memcpy(OutData, InData, 0x06);
	ConvertTrackData(InPos, &OutPos, InsCount, InsLib);
	OutSize = OutPos;
	
	return;
}

static void FixOctaveSetting(UINT16* OutPosA, UINT8* CurOct, UINT8 NewOct)
{
	UINT16 OutPos;
	
	if (*CurOct == NewOct || ! NewOct)
		return;
	
	OutPos = *OutPosA;
	if (! *CurOct)
	{
		*CurOct = NewOct;
		OutData[OutPos] = 0xEE;		OutPos ++;
		OutData[OutPos] = *CurOct;	OutPos ++;
	}
	else if (NewOct == *CurOct + 12)
	{
		OutData[OutPos] = 0xF0;	OutPos ++;
		(*CurOct) += 12;
	}
	else if (NewOct == *CurOct - 12)
	{
		OutData[OutPos] = 0xF1;	OutPos ++;
		(*CurOct) -= 12;
	}
	else
	{
		OutData[OutPos] = 0xEF;	OutPos ++;
		OutData[OutPos] = NewOct - *CurOct;
		*CurOct = NewOct;
		OutPos ++;
	}
	
	*OutPosA = OutPos;
	return;
}

static UINT8 AddToInsLib(UINT8* InsCount, INS_DATA* InsLib, const UINT8* InsData)
{
	UINT8 CurIns;
	
	for (CurIns = 0x00; CurIns < *InsCount; CurIns ++)
	{
		if (! memcmp(InsLib[CurIns].Data, InsData, 6))
			return CurIns;
	}
	
	if (*InsCount >= 0x80)
		return 0xFF;
	
	CurIns = *InsCount;
	(*InsCount) ++;
	memcpy(InsLib[CurIns].Data, InsData, 6);
	
	return CurIns;
}

static void ConvertTrackData(UINT16 InPos, UINT16* OutPosA, UINT8* InsCount, INS_DATA* InsLib)
{
	const UINT8 CMD_LENGTH[0x0E] = {5, 2, 7, 6, 3, 2, 1, 4, 1, 2, 2, 1, 1, 1};
	const UINT8 CMD_MAP[0x0E] =
	{	0xE0, 0xE1, 0xE2, 0xE3, 0xE4, 0xE5, 0xE6, 0xE7,
		0xE6,	// Master Loop -> Normal Loop (with counter == zero)
		0xE9,	// Noise Mode
		0x00,	// Def. Note Len
		0xEC,	// Vol Up
		0xED,	// Vol Down
		0xEA,	// Hold
	};
	//UINT16 InPos;
	UINT16 OutPos;
	UINT16 TempPos;
	UINT8 CurOct;
	UINT8 CmdByte;
	UINT8 CmdLen;
	UINT8 DefNoteLen;
	UINT8 Note_Val;
	UINT8 Note_Oct;
	UINT8 NoteLen;
	UINT16 NewNoteLen;
	UINT8 LastNoteCmd;
	UINT8 DidHold;
	UINT8 LoopStk;
	UINT8 LoopOct[8];
	UINT16 LoopStOfs[8];
	UINT8 CurVol;
	INT16 TempSSht;
	
	OutPos = *OutPosA;
	CurOct = 0x00;
	DefNoteLen = 0x00;
	DidHold = 0x00;
	LastNoteCmd = 0xFF;
	LoopStk = 0x00;
	CurVol = 0x80;
	while(InPos < InSize)
	{
		CmdByte = InData[InPos];
		InDstPtrs[InPos] = OutPos;
		if (CmdByte < 0x80)
		{
			InPos ++;
			NoteLen = InData[InPos];	InPos ++;
			if (! NoteLen)
				NoteLen = DefNoteLen;
			
			NewNoteLen = ConvertNoteLen(NoteLen);
			if (CmdByte == LastNoteCmd && DidHold)
			{
				OutPos --;
				Note_Val = 0x0E;	// Hold Note
			}
			else if (CmdByte < 0x7F)
			{
				LastNoteCmd = CmdByte;
				Note_Val = (CmdByte & 0x0F) >> 0;
				Note_Oct = (CmdByte & 0xF0) >> 4;
				if (Note_Oct < 7)
				{
					Note_Oct += 3;
					if (Note_Val >= 12)
					{
						if (Note_Val == 0x0F)
						{
							printf("Note -0!\n");
							while(1);
						}
						//Note_Val = Note_Val - 15 + 12;
						Note_Val -= 3;	// 0C..0F = -3 (A) .. -0 (C)
						Note_Oct --;
						if (Note_Val >= 12)
							printf("!!!");
					}
					
					Note_Oct *= 12;
					if (Note_Val == 0 && Note_Oct == CurOct + 12)
					{
						Note_Val += 12;
						Note_Oct -= 12;
					}
				}
				else
				{
					Note_Oct = 0x80;
				}
				Note_Val ++;	// first note has value 1 (rest has value 0)
				
				FixOctaveSetting(&OutPos, &CurOct, Note_Oct);
			}
			else //if (CmdByte == 0x7F)
			{
				Note_Val = 0x00;
				LastNoteCmd = 0xFF;
			}
			
			OutData[OutPos] = (Note_Val << 0) | (NewNoteLen << 4);
			OutPos ++;
			if ((NewNoteLen & 0xFF) == 0x0D)
			{
				OutData[OutPos] = NewNoteLen >> 8;
				OutPos ++;
			}
			DidHold = 0x00;
		}
		else
		{
			DidHold = 0x00;
			if (CmdByte < 0xF0)
			{
				if (CmdByte == 0x86 || CmdByte == 0x88)	// (Master) Loop Start
				{
					LoopOct[LoopStk] = CurOct;
					LoopStk ++;
					CurVol |= 0x80;
				}
				else if (CmdByte == 0x87)	// Loop End
				{
					LoopStk --;
					FixOctaveSetting(&OutPos, &CurOct, LoopOct[LoopStk]);
					CurVol |= 0x80;
				}
				
				CmdLen = CMD_LENGTH[CmdByte & 0x0F];
				OutData[OutPos] = CMD_MAP[CmdByte & 0x0F];
				
				for (TempPos = 0x01; TempPos < CmdLen; TempPos ++)
					OutData[OutPos + TempPos] = InData[InPos + TempPos];
				
				if (CmdByte == 0x82)		// set ADSR -> set Instrument
				{
					OutData[OutPos + 0x01] = AddToInsLib(InsCount, InsLib, &InData[InPos + 0x01]);
					if (OutData[OutPos + 0x01] == 0xFF)
						printf("Error!!!!!\n");
					OutData[OutPos + 0x02] = 0x00;
					OutPos = OutPos - CmdLen + 0x03;
				}
				else if (CmdByte == 0x83 || CmdByte == 0x84)	// Modulation / Detune
				{
					// duplicate the Modulation Delta (for separate PSG/FM)
					TempSSht = (INT16)ReadLE16(&InData[InPos + CmdLen - 0x02]);
					TempSSht = -TempSSht;
					WriteLE16(&OutData[OutPos + CmdLen], TempSSht);
					OutPos += 0x02;
				}
				else if (CmdByte == 0x86)	// Loop Start
				{
					LoopStOfs[LoopStk - 1] = OutPos + 0x01;
					OutData[OutPos + 0x01] = 0x00;	// default = 00
					OutPos ++;	// reserve 1 byte for Loop Count
				}
				else if (CmdByte == 0x87)	// Loop End
				{
					TempPos = LoopStOfs[LoopStk];	// copy Loop Count to command 86
					OutData[TempPos] = InData[InPos + 0x01];
					
					TempPos = ReadLE16(&InData[InPos + 0x02]);
					TempPos = InDstPtrs[TempPos] - (OutPos + 0x01);
					WriteLE16(&OutData[OutPos + 0x01], TempPos);
					OutPos --;
				}
				else if (CmdByte == 0x88)	// Loop Start
				{
					LoopStOfs[LoopStk - 1] = OutPos + 0x01;
					OutData[OutPos + 0x01] = 0x00;	// set Loop Count to 00 for Master Loop
					OutPos ++;	// reserve 1 byte for Loop Count
				}
				else if (CmdByte == 0x8A)	// set Default Note Length
				{
					DefNoteLen = InData[InPos + 0x01];
				}
				else if (CmdByte == 0x8D)	// Hold Note
				{
					DidHold = 0x01;
				}
				else if (CmdByte == 0x81)	// set Volume
				{
					if (CurVol & 0x80)
					{
						CurVol = InData[InPos + 0x01];
						if (CurVol)
							OutData[OutPos + CmdLen] = 0x0F - (0x0F - CurVol) * 2 / 3;
						else
							OutData[OutPos + CmdLen] = 0x00;
					}
					else
					{
						TempSSht = InData[InPos + 0x01] - CurVol;
						CurVol = InData[InPos + 0x01];
						OutData[OutPos + 0x00] = 0xEB;
						OutData[OutPos + 0x01] = TempSSht;
						OutData[OutPos + 0x02] = TempSSht * 2 / 3;
					}
					OutPos ++;
				}
				else if (CmdByte == 0x8B)
				{
					CurVol &= 0x7F;
					CurVol ++;
				}
				else if (CmdByte == 0x8C)
				{
					CurVol &= 0x7F;
					CurVol --;
				}
				
				InPos += CmdLen;
				if (CMD_MAP[CmdByte & 0x0F])
					OutPos += CmdLen;	// confirm only, if not nullified
			}
			else
			{
				if (LoopStk > 0)
				{
					LoopStk --;
					FixOctaveSetting(&OutPos, &CurOct, LoopOct[LoopStk]);
				}
				OutData[OutPos] = CmdByte;
				InPos ++;	OutPos ++;
				break;	// Track End
			}
		}
	}
	*OutPosA = OutPos;
	
	return;
}

static UINT16 ReadLE16(const UINT8* Data)
{
	return (Data[0x01] << 8) | (Data[0x00] << 0);
}

static void WriteLE16(UINT8* Buffer, UINT16 Value)
{
	Buffer[0x00] = (Value & 0x00FF) >> 0;
	Buffer[0x01] = (Value & 0xFF00) >> 8;
	
	return;
}
