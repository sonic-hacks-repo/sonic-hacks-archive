#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <ctype.h>	// for isspace()
#include <windows.h>

#include "stdtype.h"
#include "ini_lib.h"


#define FILE_PATH	"D:/VStudio-Programme/ASM68k/SoundDrvs/Sonic1SMS/NewFormat/"
// Structures and Constants
#define OP_INT		0x00
#define OP_FLOAT	0x80
enum
{
	OP_ADD = 0x01,
	OP_SUB,
	OP_MUL,
	OP_DIV,
	OP_MOD,
	OP_POW = 0x08,
	OP_LOG,
	OP_EXP,
	OP_AND = 0x10,
	OP_OR,
	OP_XOR,
	OP_ANDL = 0x14,
	OP_ORL,
	OP_XORL,
	OP_LSHIFT = 0x20,
	OP_RSHIFT,
	OP_NOT,
};
static UINT8 OPERATOR_MAP[0x100];

typedef struct _parameter_operator
{
	UINT8 Operator;
	union
	{
		INT32 ValInt;
		float ValFloat;
	};
} PARAM_OP;

#define BYTORD_MAX		0x04
#define BYTORD_HEX		0x04
#define BYTORD_NOTE		0x10
#define BYTORD_DELAY	0x20
#define BYTORD_POINTER	0x80
#define BYTORD_RELATIVE	0x40
typedef struct _parameter_definition
{
	UINT8 Flags;
	UINT8 ByteOrdLen;
	UINT8 OperatorCount;
	UINT8 ByteOrder[BYTORD_MAX];
	PARAM_OP* Operators;
} PARAM_DEF;
#define CDFLG_INLINE		0x01
#define CDFLG_LOOP			0x10
#define CDFLG_SUBROUTINE	0x20
#define CDFLG_JUMP			0x40
#define CDFLG_TRACK_END		0x80
typedef struct _command_definition
{
	UINT8 Flags;
	UINT8 IdentLen;
	UINT8* IdentData;
	UINT8 AddIdentFrom;
	UINT8 AddIdentTo;
	UINT8 Length;
	char* Name;
	
	UINT8 ParamCount;
	PARAM_DEF* Params;
} CMD_DEF;

CMD_DEF DefaultCDef = {CDFLG_INLINE, 0x00, NULL, 0x00, 0xFF, 0x01, NULL, 0x00, NULL};

typedef struct _sequence_parse_item SEQ_PITEM;
typedef struct _sequence_definition
{
	UINT16 HdrDefCount;
	CMD_DEF* HdrDefs;
	UINT16 CmdDefCount;
	CMD_DEF* CmdDefs;
} SEQ_DEF;

#define PIFLG_BLK_ST	0x01	// Basic Block Start
#define PIFLG_BLK_END	0x80	// Basic Block End
//typedef struct _sequence_parse_item SEQ_PITEM;
struct _sequence_parse_item
{
	UINT8 Flags;
	UINT16 Pos;
	INT16 LabelID;
	char* LabelName;	// sprintf-string, used together with LabelID
	const SEQ_PITEM* LblRef;
	CMD_DEF* CmdDef;
};

typedef struct _sequence_parse_queue PQUEUE;
struct _sequence_parse_queue
{
	UINT16 Offset;
	PQUEUE* next;
};

#define SPTR_MODE_UNDEF	0x00
#define SPTR_MODE_TRK	0x01
#define SPTR_MODE_SUB	0x02
#define SPTR_MODE_LOOP	0x04
typedef struct _sequence_pointer_list PLIST;
struct _sequence_pointer_list
{
	UINT16 Offset;
	UINT8 Mode;
	UINT8 AddID;	// additional ID
	const SEQ_PITEM* DstPItem;
	PLIST* next;
};

typedef struct _sequence_parse_data
{
	UINT32 ItemCount;
	SEQ_PITEM* Items;
	
	PLIST* PtrListHead;
	
	PQUEUE* PQHead;	// Pointer Queue ("to-process" list)
	PQUEUE* PQEnd;
} SEQ_PDATA;

#define LNST_MID_LINE	0x01
typedef struct asm_line_state
{
	FILE* hFile;
	char Buffer[0x200];
	const char* LblBase;
	UINT32 StrPos;
	UINT8 Flags;
	UINT8 ValsOnLine;
} LINE_STATE;

typedef void (*OP_FUNC)(PARAM_OP* ValueDst, const PARAM_OP* ValueOp);
static OP_FUNC OPERATOR_FUNC[0x80];

// Function Prototypes
void InitOperatorParsing(void);
INLINE INT32 DoOp_GetIntValue(const PARAM_OP* Val);
INLINE float DoOp_GetFltValue(const PARAM_OP* Val);

static void DoOp_Add(PARAM_OP* ValueDst, const PARAM_OP* ValueOp);
static void DoOp_Sub(PARAM_OP* ValueDst, const PARAM_OP* ValueOp);
static void DoOp_Mul(PARAM_OP* ValueDst, const PARAM_OP* ValueOp);
static void DoOp_Div(PARAM_OP* ValueDst, const PARAM_OP* ValueOp);
static void DoOp_Mod(PARAM_OP* ValueDst, const PARAM_OP* ValueOp);
static void DoOp_Pow(PARAM_OP* ValueDst, const PARAM_OP* ValueOp);
static void DoOp_Log(PARAM_OP* ValueDst, const PARAM_OP* ValueOp);
static void DoOp_Exp(PARAM_OP* ValueDst, const PARAM_OP* ValueOp);

static void DoOp_And(PARAM_OP* ValueDst, const PARAM_OP* ValueOp);
static void DoOp_Or(PARAM_OP* ValueDst, const PARAM_OP* ValueOp);
static void DoOp_Xor(PARAM_OP* ValueDst, const PARAM_OP* ValueOp);
static void DoOp_LShift(PARAM_OP* ValueDst, const PARAM_OP* ValueOp);
static void DoOp_RShift(PARAM_OP* ValueDst, const PARAM_OP* ValueOp);
static void DoOp_Not(PARAM_OP* ValueDst, const PARAM_OP* ValueOp);

static void DoOperators(PARAM_OP* Value, UINT8 OpCount, const PARAM_OP* Operators);


static void ReadOperatorList(const char* TextStr, const char** EndTxtStr, PARAM_DEF* ParamDef);
static void ParseParameter(const char* TextStr, const char** EndTxtStr, PARAM_DEF* ParamDef);
static void ParseParameterLine(const char* TextStr, const char** EndTxtStr, CMD_DEF* CmdDef);
static void GetColumns(char* TextStr, UINT8 MaxCols, char** ColumnPtrs);
static void ParseDefinitionLine(char* TextStr, char** EndTxtStr, CMD_DEF* CmdDef);
void LoadDefinitionFile(const char* FileName, SEQ_DEF* SeqDef);

static INT32 GetParamValue(UINT16 BasePos, const PARAM_DEF* ParamDef);
static UINT16 GetParamPointer(UINT16 BasePos, const PARAM_DEF* ParamDef);
static void AddToPointerList(UINT16 Offset, UINT8 Mode, SEQ_PDATA* SeqPData);
static void AddToPQueue(PQUEUE** PQHead, PQUEUE** PQEnd, UINT16 Offset);
static int Seq_PItem_Compare(const void* Ptr1, const void* Ptr2);
static void ParseSeqData(const SEQ_DEF* SeqDef, SEQ_PDATA* SeqPData);
static void SetSeqDataLabels(SEQ_PDATA* SeqPData);

static void FlushLineData(LINE_STATE* LState);
static void Line_EnsureCommand(LINE_STATE* LState, const char* CmdName);
static void PrintLabelRecurse(LINE_STATE* LState, const SEQ_PITEM* PItem);
static void PrintLabel(LINE_STATE* LState, const SEQ_PITEM* PItem, UINT16 Offset);
//static void PrintLabel(LINE_STATE* LState, const char* String, UINT32 Value, UINT16 Offset);
static void PrintCommandStr(LINE_STATE* LState, const char* String);
static void PrintLineStr(LINE_STATE* LState, const char* String);
static void PrintLineByte(LINE_STATE* LState, UINT8 Value);
static void PrintLineValue(LINE_STATE* LState, const PARAM_DEF* ParamDef, UINT16 FilePos, const PLIST* SeqPtrList);
static void PrintSeqData(SEQ_PDATA* SeqPData, FILE* hFile, const char* BaseLbl);
static void FreeSeqData(SEQ_PDATA* SeqPData);
UINT8 LoadSeqData(const char* FileName);



UINT32 FileSize;
UINT8* FileData;

void InitOperatorParsing(void)
{
	memset(OPERATOR_MAP, 0x00, sizeof(OPERATOR_MAP));
	memset(OPERATOR_FUNC, 0x00, sizeof(OPERATOR_FUNC));
	
	OPERATOR_MAP['+'] = OP_ADD;
	OPERATOR_MAP['-'] = OP_SUB;
	OPERATOR_MAP['*'] = OP_MUL;
	OPERATOR_MAP['/'] = OP_DIV;
	OPERATOR_MAP['%'] = OP_MOD;
	OPERATOR_MAP['p'] = OP_POW;
	OPERATOR_MAP['l'] = OP_LOG;
	OPERATOR_MAP['e'] = OP_EXP;
	OPERATOR_MAP['&'] = OP_AND;
	OPERATOR_MAP['|'] = OP_OR;
	OPERATOR_MAP['^'] = OP_XOR;
	OPERATOR_MAP['~'] = OP_NOT;
	OPERATOR_MAP['<'] = OP_LSHIFT;
	OPERATOR_MAP['>'] = OP_RSHIFT;
	
	OPERATOR_FUNC[OP_ADD] = &DoOp_Add;
	OPERATOR_FUNC[OP_SUB] = &DoOp_Sub;
	OPERATOR_FUNC[OP_MUL] = &DoOp_Mul;
	OPERATOR_FUNC[OP_DIV] = &DoOp_Div;
	OPERATOR_FUNC[OP_MOD] = &DoOp_Mod;
	OPERATOR_FUNC[OP_POW] = &DoOp_Pow;
	OPERATOR_FUNC[OP_LOG] = &DoOp_Log;
	OPERATOR_FUNC[OP_EXP] = &DoOp_Exp;
	OPERATOR_FUNC[OP_AND] = &DoOp_And;
	OPERATOR_FUNC[OP_OR] = &DoOp_Or;
	OPERATOR_FUNC[OP_XOR] = &DoOp_Xor;
	OPERATOR_FUNC[OP_ANDL] = NULL;
	OPERATOR_FUNC[OP_ORL] = NULL;
	OPERATOR_FUNC[OP_XORL] = NULL;
	OPERATOR_FUNC[OP_LSHIFT] = &DoOp_LShift;
	OPERATOR_FUNC[OP_RSHIFT] = &DoOp_RShift;
	OPERATOR_FUNC[OP_NOT] = &DoOp_Not;
	
	return;
}

INLINE INT32 DoOp_GetIntValue(const PARAM_OP* Val)
{
	if (Val->Operator & OP_FLOAT)
		return (INT32)Val->ValFloat;
	else
		return Val->ValInt;
}

INLINE float DoOp_GetFltValue(const PARAM_OP* Val)
{
	if (Val->Operator & OP_FLOAT)
		return Val->ValFloat;
	else
		return (float)Val->ValInt;
}


static void DoOp_Add(PARAM_OP* ValueDst, const PARAM_OP* ValueOp)
{
	if (ValueDst->Operator & OP_FLOAT)
		ValueDst->ValFloat += DoOp_GetFltValue(ValueOp);
	else
		ValueDst->ValInt += DoOp_GetIntValue(ValueOp);
	return;
}

static void DoOp_Sub(PARAM_OP* ValueDst, const PARAM_OP* ValueOp)
{
	if (ValueDst->Operator & OP_FLOAT)
		ValueDst->ValFloat -= DoOp_GetFltValue(ValueOp);
	else
		ValueDst->ValInt -= DoOp_GetIntValue(ValueOp);
	return;
}

static void DoOp_Mul(PARAM_OP* ValueDst, const PARAM_OP* ValueOp)
{
	if (ValueDst->Operator & OP_FLOAT)
		ValueDst->ValFloat *= DoOp_GetFltValue(ValueOp);
	else
		ValueDst->ValInt *= DoOp_GetIntValue(ValueOp);
	return;
}

static void DoOp_Div(PARAM_OP* ValueDst, const PARAM_OP* ValueOp)
{
	if (ValueDst->Operator & OP_FLOAT)
		ValueDst->ValFloat /= DoOp_GetFltValue(ValueOp);
	else
		ValueDst->ValInt /= DoOp_GetIntValue(ValueOp);
	return;
}

static void DoOp_Mod(PARAM_OP* ValueDst, const PARAM_OP* ValueOp)
{
	if (ValueDst->Operator & OP_FLOAT)
	{
		float OpVal = DoOp_GetFltValue(ValueOp);
		ValueDst->ValFloat -= (int)(ValueDst->ValFloat / OpVal) * OpVal;
	}
	else
	{
		ValueDst->ValInt %= DoOp_GetIntValue(ValueOp);
	}
	return;
}

static void DoOp_Pow(PARAM_OP* ValueDst, const PARAM_OP* ValueOp)
{
	if (ValueDst->Operator & OP_FLOAT)
		ValueDst->ValFloat = powf(ValueDst->ValFloat, DoOp_GetFltValue(ValueOp));
	else
		ValueDst->ValInt = (int)pow(ValueDst->ValInt, DoOp_GetIntValue(ValueOp));
	return;
}

static void DoOp_Log(PARAM_OP* ValueDst, const PARAM_OP* ValueOp)
{
	// TODO: Take logarithm to base of ValueOp
	/*if (ValueDst->Operator & OP_FLOAT)
		ValueDst->ValFloat = logf(ValueDst->ValFloat, DoOp_GetFltValue(ValueOp));
	else
		ValueDst->ValInt = (int)pow(ValueDst->ValInt, DoOp_GetIntValue(ValueOp);*/
	return;
}

static void DoOp_Exp(PARAM_OP* ValueDst, const PARAM_OP* ValueOp)
{
	if (ValueDst->Operator & OP_FLOAT)
		ValueDst->ValFloat = powf(DoOp_GetFltValue(ValueOp), ValueDst->ValFloat);
	else
		ValueDst->ValInt = (int)pow(DoOp_GetIntValue(ValueOp), ValueDst->ValInt);
	/*UINT32 Value;
	
	ValueDst->Operator &= ~OP_FLOAT;
	Value = DoOp_GetIntValue(ValueDst);
	
	if (Value < 7)
		ValueDst->ValInt = (int)(192 >> Value);
	else
		ValueDst->ValInt = (int)(64 >> (Value-7));*/
	
	return;
}


static void DoOp_And(PARAM_OP* ValueDst, const PARAM_OP* ValueOp)
{
	ValueDst->ValInt &= DoOp_GetIntValue(ValueOp);
	return;
}

static void DoOp_Or(PARAM_OP* ValueDst, const PARAM_OP* ValueOp)
{
	ValueDst->ValInt |= DoOp_GetIntValue(ValueOp);
	return;
}

static void DoOp_Xor(PARAM_OP* ValueDst, const PARAM_OP* ValueOp)
{
	ValueDst->ValInt ^= DoOp_GetIntValue(ValueOp);
	return;
}

static void DoOp_LShift(PARAM_OP* ValueDst, const PARAM_OP* ValueOp)
{
	ValueDst->ValInt <<= DoOp_GetIntValue(ValueOp);
	return;
}

static void DoOp_RShift(PARAM_OP* ValueDst, const PARAM_OP* ValueOp)
{
	ValueDst->ValInt >>= DoOp_GetIntValue(ValueOp);
	return;
}

static void DoOp_Not(PARAM_OP* ValueDst, const PARAM_OP* ValueOp)
{
	ValueDst->ValInt = ~ValueDst->ValInt;
	return;
}


static void DoOperators(PARAM_OP* Value, UINT8 OpCount, const PARAM_OP* Operators)
{
	UINT8 CurOp;
	const PARAM_OP* TempOp;
	PARAM_OP CurVal;
	OP_FUNC TempOpFunc;
	
	if (! OpCount)
		return;	// no operators - nothing to do
	
	CurVal = *Value;
	for (CurOp = 0x00; CurOp < OpCount; CurOp ++)
	{
		TempOp = &Operators[CurOp];
		if ((TempOp->Operator & OP_FLOAT) && ! (CurVal.Operator & OP_FLOAT))
		{
			CurVal.ValFloat = (float)CurVal.ValInt;
			CurVal.Operator |= OP_FLOAT;
		}
		if ((TempOp->Operator & ~OP_FLOAT) >= OP_AND && (CurVal.Operator & OP_FLOAT))
		{
			CurVal.ValInt = (int)CurVal.ValFloat;
			CurVal.Operator &= ~OP_FLOAT;
		}
		
		TempOpFunc = OPERATOR_FUNC[TempOp->Operator & 0x7F];
		if (TempOpFunc != NULL)
			TempOpFunc(&CurVal, TempOp);
	}
	
	*Value = CurVal;
	return;
}



// Example line: "00o&0x0F", Byte = 00, 'o' - Operator, TextStr = "&0x0F" 
static void ReadOperatorList(const char* TextStr, const char** EndTxtStr, PARAM_DEF* ParamDef)
{
	const char* CurStr;
	char* EndStr;
	UINT8 OpCount;
	UINT8 OpAlloc;
	PARAM_OP* OpArr;
	PARAM_OP* TempOp;
	
	OpAlloc = 0x10;
	OpArr = (PARAM_OP*)malloc(OpAlloc * sizeof(PARAM_OP));
	
	CurStr = TextStr;
	OpCount = 0x00;
	while(*CurStr > ' ' && OpCount < 0xFF)
	{
		if (OPERATOR_MAP[(UINT8)*CurStr] == 0x00)
			break;
		
		if (OpCount >= OpAlloc)
		{
			OpAlloc += 0x10;
			OpArr = (PARAM_OP*)realloc(OpArr, OpAlloc * sizeof(PARAM_OP));
		}
		TempOp = &OpArr[OpCount];
		OpCount ++;
		
		TempOp->Operator = OPERATOR_MAP[(UINT8)*CurStr];
		CurStr ++;
		if (TempOp->Operator == OP_NOT)
			continue;	// This operator has no parameter.
		if (TempOp->Operator >= OP_LSHIFT && TempOp->Operator <= OP_LSHIFT)
		{
			if (OPERATOR_MAP[(UINT8)*CurStr] != TempOp->Operator)
			{
				OpCount --;
				break;	// bit shift operators are 2 chars long
			}
			CurStr ++;
		}
		else if (TempOp->Operator >= OP_AND && TempOp->Operator <= OP_XOR)
		{
			if (OPERATOR_MAP[(UINT8)*CurStr] == TempOp->Operator)
			{
				CurStr ++;
				//TempOp->Operator += (OP_ANDL - OP_AND);
				TempOp->Operator |= 0x04;
				TempOp->Operator &= ~0x04;	// not supported yet
			}
		}
		
		TempOp->ValInt = (INT32)strtol(CurStr, &EndStr, 0);
		if (EndStr != NULL && *EndStr == '.')
		{
			TempOp->ValFloat = (float)strtod(CurStr, &EndStr);
			if (EndStr == CurStr)
			{
				OpCount --;
				break;	// invalid number - stop
			}
			TempOp->Operator |= OP_FLOAT;
		}
		CurStr = EndStr;
	}
	
	if (! OpCount)
	{
		free(OpArr);	OpArr = NULL;
	}
	else if (OpCount < OpAlloc)
	{
		OpArr = (PARAM_OP*)realloc(OpArr, OpCount * sizeof(PARAM_OP));
	}
	ParamDef->OperatorCount = OpCount;
	ParamDef->Operators = OpArr;
	
	if (EndTxtStr != NULL)
		*EndTxtStr = CurStr;
	return;
}

static void ParseParameter(const char* TextStr, const char** EndTxtStr, PARAM_DEF* ParamDef)
{
	const char* CurStr;
	char* EndStr;
	UINT8 BytOLen;
	UINT8 BytOrder[BYTORD_MAX];
	
	// Example Lines:
	//	"00o&0x0F"
	//	"03/02Pr"
	CurStr = TextStr;
	BytOLen = 0x00;
	do
	{
		BytOrder[BytOLen] = (UINT8)strtoul(CurStr, &EndStr, 0x10);
		if (EndStr == CurStr)
			break;	// invalid number
		BytOLen ++;
		CurStr = EndStr;
		
		if (*CurStr != '/')
			break;
		CurStr ++;
	} while(BytOLen < 0x10);
	
	ParamDef->Flags = 0x00;
	ParamDef->ByteOrdLen = BytOLen;
	memcpy(ParamDef->ByteOrder, BytOrder, BytOLen);
	ParamDef->OperatorCount = 0x00;
	ParamDef->Operators = NULL;
	
	while(*CurStr > ' ')
	{
		if (*CurStr == '_')
		{
			// separator - does nothing but improve readability
		}
		else if (*CurStr == 'P')
		{
			ParamDef->Flags |= BYTORD_POINTER;
		}
		else if (*CurStr == 'r' || *CurStr == 's')
		{
			ParamDef->Flags |= BYTORD_RELATIVE;
		}
		else if (*CurStr == 'h')
		{
			ParamDef->Flags |= BYTORD_HEX;
		}
		else if (*CurStr == 'N')
		{
			ParamDef->Flags |= BYTORD_NOTE;
		}
		else if (*CurStr == 'D')
		{
			ParamDef->Flags |= BYTORD_DELAY;
		}
		else if (*CurStr == 'o')
		{
			CurStr ++;
			ReadOperatorList(CurStr, &EndStr, ParamDef);
			CurStr = EndStr;
			continue;
		}
		else
		{
			break;
		}
		CurStr ++;
	}
	
	if (EndTxtStr != NULL)
		*EndTxtStr = CurStr;
	return;
}

static void ParseParameterLine(const char* TextStr, const char** EndTxtStr, CMD_DEF* CmdDef)
{
	const char* CurStr;
	char* EndStr;
	UINT8 PDefCnt;
	UINT8 PDefAlloc;
	PARAM_DEF* PDefs;
	
	CurStr = TextStr;
	if (CurStr != NULL)
	{
		while(isspace(*CurStr))
			CurStr ++;
	}
	
	if (CurStr == NULL || *CurStr == ';')
	{
		CmdDef->ParamCount = 0x00;
		CmdDef->Params = NULL;
		return;
	}
	
	PDefAlloc = 0x10;
	PDefs = (PARAM_DEF*)malloc(PDefAlloc * sizeof(PARAM_DEF));
	PDefCnt = 0x00;
	while(isxdigit(*CurStr))
	{
		if (PDefCnt >= PDefAlloc)
		{
			PDefAlloc += 0x10;
			PDefs = (PARAM_DEF*)malloc(PDefAlloc * sizeof(PARAM_DEF));
		}
		
		ParseParameter(CurStr, &EndStr, &PDefs[PDefCnt]);
		if (! PDefs[PDefCnt].ByteOrdLen)
			break;
		PDefCnt ++;
		
		CurStr = EndStr;
		while(isspace(*CurStr))
			CurStr ++;
	}
	
	if (! PDefCnt)
	{
		free(PDefs);	PDefs = NULL;
	}
	else if (PDefCnt < PDefAlloc)
	{
		PDefs = (PARAM_DEF*)realloc(PDefs, PDefCnt * sizeof(PARAM_DEF));
	}
	CmdDef->ParamCount = PDefCnt;
	CmdDef->Params = PDefs;
	
	if (EndTxtStr != NULL)
		*EndTxtStr = CurStr;
	return;
}

static void GetColumns(char* TextStr, UINT8 MaxCols, char** ColumnPtrs)
{
	char* CurStr;
	UINT8 CurCol;
	
	CurStr = TextStr;
	for (CurCol = 0; CurCol < MaxCols; CurCol ++)
	{
		if (*CurStr == ';')
			*CurStr = '\0';
		if (*CurStr == '\0')
			break;
		
		ColumnPtrs[CurCol] = CurStr;
		while(*CurStr != '\0' && ! isspace(*CurStr))	// skip the word
			CurStr ++;
		while(isspace(*CurStr))		// skip the tab/space
			CurStr ++;
	}
	if (CurCol < MaxCols && *CurStr != '\0')
	{
		ColumnPtrs[CurCol] = CurStr;
		CurCol ++;
	}
	for (; CurCol < MaxCols; CurCol ++)
		ColumnPtrs[CurCol] = NULL;
	
	return;
}

static void ParseDefinitionLine(char* TextStr, char** EndTxtStr, CMD_DEF* CmdDef)
{
	char* CurStr;
	char* EndStr;
	UINT32 StrLen;
	char* ColumnPtrs[4];
	
	memset(CmdDef, 0x00, sizeof(CMD_DEF));
	GetColumns(TextStr, 4, ColumnPtrs);
	if (ColumnPtrs[2] == NULL)
		return;	// need at least the Name column
	
	CmdDef->Flags = 0x00;
	CmdDef->IdentLen = 0x00;
	CmdDef->IdentData = NULL;
	
	// TODO: handle Ident
	CmdDef->AddIdentFrom = (UINT8)strtoul(ColumnPtrs[0], &EndStr, 0x10);
	if (EndStr != NULL && ! strncmp(EndStr, "..", 2))
	{
		// handle 00..7F
		EndStr += 2;
		CmdDef->AddIdentTo = (UINT8)strtoul(EndStr, NULL, 0x10);
		if (CmdDef->AddIdentTo < CmdDef->AddIdentFrom)
			CmdDef->AddIdentTo = CmdDef->AddIdentFrom;
	}
	else
	{
		CmdDef->AddIdentTo = CmdDef->AddIdentFrom;
	}
	
	CmdDef->Length = (UINT8)strtoul(ColumnPtrs[1], NULL, 0x10);
	if (! CmdDef->Length)
		CmdDef->Length = 1;	// prevent endless loops
	
	CurStr = ColumnPtrs[2];
	while(1)
	{
		if (*CurStr == '-')
		{
			CmdDef->Flags |= CDFLG_INLINE;
			CurStr ++;
		}
		else if (*CurStr == '|')
		{
			CmdDef->Flags |= CDFLG_TRACK_END;
			CurStr ++;
		}
		else if (*CurStr == '<')
		{
			CmdDef->Flags |= CDFLG_LOOP;
			CurStr ++;
		}
		else if (*CurStr == '>')
		{
			CmdDef->Flags |= CDFLG_JUMP;
			CurStr ++;
		}
		else if (*CurStr == '^')
		{
			CmdDef->Flags |= CDFLG_SUBROUTINE;
			CurStr ++;
		}
		else
		{
			break;
		}
	}
	
	EndStr = CurStr;
	while(*EndStr != '\0' && ! isspace(*EndStr))
		EndStr ++;
	StrLen = EndStr - CurStr;
	CmdDef->Name = (char*)malloc((StrLen + 1) * sizeof(char));
	strncpy(CmdDef->Name, CurStr, StrLen);
	CmdDef->Name[StrLen] = '\0';
	
	ParseParameterLine(ColumnPtrs[3], NULL, CmdDef);
	
	return;
}

void LoadDefinitionFile(const char* FileName, SEQ_DEF* SeqDef)
{
	FILE* hFile;
	char LineStr[0x200];
	char* LToken;
	char* RToken;
	UINT8 Group;
	UINT8 RetVal;
	
	UINT16 HdrDefCnt;
	UINT16 HdrDefAlloc;
	CMD_DEF* HdrDefs;
	UINT16 CmdDefCnt;
	UINT16 CmdDefAlloc;
	CMD_DEF* CmdDefs;
	
	hFile = fopen(FileName, "rt");
	if (hFile == NULL)
	{
		printf("Error opening %s\n", FileName);
		return;
	}
	
	HdrDefAlloc = 0x80;
	HdrDefs = (CMD_DEF*)malloc(HdrDefAlloc * sizeof(CMD_DEF));
	CmdDefAlloc = 0x80;
	CmdDefs = (CMD_DEF*)malloc(CmdDefAlloc * sizeof(CMD_DEF));
	
	Group = 0xFF;
	CmdDefCnt = 0x00;
	HdrDefCnt = 0x00;
	while(! feof(hFile))
	{
		RetVal = GetTextLine(0x200, LineStr, hFile);
		if (RetVal)
			break;
		
		RetVal = GetTokenPtrs(LineStr, &LToken, &RToken);
		if (*LToken == '[')
		{
			// [Section]
			if (! _stricmp(RToken, "Commands"))
				Group = 0x01;
			else if (! _stricmp(RToken, "Header"))
				Group = 0x00;
			else
				Group = 0xFF;
			continue;
		}
		else if (Group == 0xFF)
		{
			continue;
		}
		
		if (Group == 0x00)		// [Header] group
		{
			ParseDefinitionLine(LineStr, NULL, &HdrDefs[HdrDefCnt]);
			if (HdrDefs[HdrDefCnt].Length)
				HdrDefCnt ++;
		}
		else if (Group == 0x01)	// [Commands] group
		{
			if (CmdDefCnt >= CmdDefAlloc)
			{
				CmdDefAlloc += 0x80;
				CmdDefs = (CMD_DEF*)realloc(CmdDefs, CmdDefAlloc * sizeof(CMD_DEF));
			}
			ParseDefinitionLine(LineStr, NULL, &CmdDefs[CmdDefCnt]);
			if (CmdDefs[CmdDefCnt].Length)
				CmdDefCnt ++;
		}
	}
	
	fclose(hFile);
	
	if (CmdDefCnt < CmdDefAlloc)
		CmdDefs = (CMD_DEF*)realloc(CmdDefs, CmdDefCnt * sizeof(CMD_DEF));
	SeqDef->CmdDefCount = CmdDefCnt;
	SeqDef->CmdDefs = CmdDefs;
	
	SeqDef->HdrDefCount = HdrDefCnt;
	SeqDef->HdrDefs = HdrDefs;
	return;
}


static INT32 GetParamValue(UINT16 BasePos, const PARAM_DEF* ParamDef)
{
	UINT8 ByteOrdLen;
	UINT8 CurByt;
	INT32 Value;
	
	ByteOrdLen = ParamDef->ByteOrdLen & 0x0F;
	Value = 0x00;
	if (ParamDef->Flags & BYTORD_RELATIVE)
	{
		if (FileData[BasePos + ParamDef->ByteOrder[0x00]] & 0x80)	// sign bit set?
			Value = -1;
	}
	for (CurByt = 0x00; CurByt < ByteOrdLen; CurByt ++)
	{
		Value <<= 8;
		Value |= FileData[BasePos + ParamDef->ByteOrder[CurByt]];
	}
	
	return Value;
}

static UINT16 GetParamPointer(UINT16 BasePos, const PARAM_DEF* ParamDef)
{
	PARAM_OP PtrVal;
	UINT8 ByteOrdLen;
	UINT8 CurByt;
	UINT8 MinOfs;
	
	PtrVal.Operator = OP_INT;
	PtrVal.ValInt = 0x00;
	ByteOrdLen = ParamDef->ByteOrdLen & 0x0F;
	MinOfs = 0xFF;
	for (CurByt = 0x00; CurByt < ByteOrdLen; CurByt ++)
	{
		PtrVal.ValInt <<= 8;
		PtrVal.ValInt |= FileData[BasePos + ParamDef->ByteOrder[CurByt]];
		if (MinOfs > ParamDef->ByteOrder[CurByt])
			MinOfs = ParamDef->ByteOrder[CurByt];
	}
	
	// absolute pointers don't require post-processing
	if (ParamDef->Flags & BYTORD_RELATIVE)
	{
		DoOperators(&PtrVal, ParamDef->OperatorCount, ParamDef->Operators);
		PtrVal.ValInt = BasePos + MinOfs + DoOp_GetIntValue(&PtrVal);
	}
	
	return PtrVal.ValInt;
}

static void AddToPointerList(UINT16 Offset, UINT8 Mode, SEQ_PDATA* SeqPData)
{
	// Note: Adds the pointer to a sorted queue.
	PLIST* CurPtr;
	PLIST* LastPtr;
	PLIST* NewPtr;
	
	CurPtr = SeqPData->PtrListHead;
	if (CurPtr == NULL || CurPtr->Offset > Offset)
	{
		NewPtr = (PLIST*)malloc(sizeof(PLIST));
		NewPtr->Offset = Offset;
		NewPtr->Mode = Mode;
		NewPtr->AddID = 0xFF;
		NewPtr->DstPItem = NULL;
		NewPtr->next = CurPtr;
		SeqPData->PtrListHead = NewPtr;
		return;
	}
	
	while(CurPtr != NULL && CurPtr->Offset <= Offset)
	{
		if (CurPtr->Offset == Offset)
		{
			CurPtr->Mode |= Mode;
			return;
		}
		LastPtr = CurPtr;
		CurPtr = CurPtr->next;
	}
	
	NewPtr = (PLIST*)malloc(sizeof(PLIST));
	NewPtr->Offset = Offset;
	NewPtr->Mode = Mode;
	NewPtr->AddID = 0xFF;
	NewPtr->DstPItem = NULL;
	NewPtr->next = CurPtr;
	LastPtr->next = NewPtr;
	return;
}

static void AddToPQueue(PQUEUE** PQHead, PQUEUE** PQEnd, UINT16 Offset)
{
	PQUEUE* NewPQ;
	
	NewPQ = (PQUEUE*)malloc(sizeof(PQUEUE));
	NewPQ->Offset = Offset;
	NewPQ->next = NULL;
	
	if (*PQHead == NULL)
		*PQHead = NewPQ;
	if (*PQEnd != NULL)
		(*PQEnd)->next = NewPQ;
	*PQEnd = NewPQ;
	
	return;
}

static int Seq_PItem_Compare(const void* Ptr1, const void* Ptr2)
{
	const SEQ_PITEM* Item1 = (SEQ_PITEM*)Ptr1;
	const SEQ_PITEM* Item2 = (SEQ_PITEM*)Ptr2;
	
	if (Item1->Pos == Item2->Pos)
		return 0;
	else if (Item1->Pos < Item2->Pos)
		return -1;
	else //if (Item1->Pos > Item2->Pos)
		return +1;
	//return (int)Item1->Pos - (int)Item2->Pos;
}

static void ParseSeqData(const SEQ_DEF* SeqDef, SEQ_PDATA* SeqPData)
{
	UINT32 PItmCount;
	UINT32 PItmAlloc;
	SEQ_PITEM* PItems;
	UINT8* FileMask;
	UINT16 CurPos;
	UINT16 CurCmd;
	UINT8 TempByt;
	UINT16 TempPos;
	CMD_DEF* TempCDef;
	SEQ_PITEM* TempPItem;
	PQUEUE* TempPQueue;
	
	FileMask = (UINT8*)malloc(FileSize);
	memset(FileMask, 0x00, FileSize);
	
	PItmAlloc = 0x1000;
	PItems = (SEQ_PITEM*)malloc(PItmAlloc * sizeof(SEQ_PITEM));
	PItmCount = 0x00;
	
	for (CurPos = 0x00; CurPos < FileSize; )
	{
		if (FileMask[CurPos])
			break;
		TempPItem = &PItems[PItmCount];
		PItmCount ++;
		
		TempPItem->Flags = 0x00;
		TempPItem->Pos = CurPos;
		TempPItem->LabelID = -1;
		TempPItem->LabelName = NULL;
		TempPItem->LblRef = NULL;
		TempPItem->CmdDef = NULL;
		for (CurCmd = 0x00; CurCmd < SeqDef->HdrDefCount; CurCmd ++)
		{
			TempCDef = &SeqDef->HdrDefs[CurCmd];
			//TempByt = FileData[CurPos];
			//if (TempByt >= TempCDef->AddIdentFrom && TempByt <= TempCDef->AddIdentTo)
			if (CurPos >= TempCDef->AddIdentFrom)
			{
				TempPItem->CmdDef = TempCDef;
				//break;
			}
		}
		
		TempCDef = TempPItem->CmdDef;
		for (TempPos = 0x00; TempPos < TempCDef->Length; TempPos ++)
			FileMask[CurPos + TempPos] |= 0x01;	// mark as "processed"
		
		TempPos = 0x0000;
		for (CurCmd = 0x00; CurCmd < TempCDef->ParamCount; CurCmd ++)
		{
			if (TempCDef->Params[CurCmd].Flags & BYTORD_POINTER)
			{
				TempPos = GetParamPointer(CurPos, &TempCDef->Params[CurCmd]);
				if (TempPos >= FileSize || ! TempPos)
					continue;
				AddToPointerList(TempPos, SPTR_MODE_TRK, SeqPData);
				if (! FileMask[TempPos])
				{
					FileMask[TempPos] |= 0x02;	// mark as "pointer noted"
					AddToPQueue(&SeqPData->PQHead, &SeqPData->PQEnd, TempPos);
				}
			}
		}
		
		CurPos += TempCDef->Length;
	}
	
	/*TempPQueue = SeqPData->PQHead;
	while(TempPQueue != NULL)
	{
		AddToPointerList(TempPQueue->Offset, SPTR_MODE_TRK, SeqPData);
		TempPQueue = TempPQueue->next;
	}*/
	
	while(SeqPData->PQHead != NULL)
	{
		CurPos = SeqPData->PQHead->Offset;
		
		if (CurPos < FileSize)
			FileMask[CurPos] |= 0x02;
	
	while(CurPos < FileSize)
	{
		if (PItmCount >= PItmAlloc)
		{
			PItmAlloc += 0x1000;
			PItems = (SEQ_PITEM*)realloc(PItems, PItmAlloc * sizeof(SEQ_PITEM));
		}
		TempPItem = &PItems[PItmCount];
		PItmCount ++;
		
		TempPItem->Flags = 0x00;
		TempPItem->Pos = CurPos;
		TempPItem->LabelID = -1;
		TempPItem->LabelName = NULL;
		TempPItem->LblRef = NULL;
		TempPItem->CmdDef = NULL;
		for (CurCmd = 0x00; CurCmd < SeqDef->CmdDefCount; CurCmd ++)
		{
			TempCDef = &SeqDef->CmdDefs[CurCmd];
			if (! TempCDef->IdentLen ||
				! memcmp(&FileData[CurPos], TempCDef->IdentData, TempCDef->IdentLen))
			{
				TempByt = FileData[CurPos + TempCDef->IdentLen];
				if (TempByt >= TempCDef->AddIdentFrom && TempByt <= TempCDef->AddIdentTo)
				{
					TempPItem->CmdDef = TempCDef;
					break;
				}
			}
		}
		if (TempPItem->CmdDef == NULL)
		{
			printf("Unknown Command %02X at Pos %04X!\n", FileData[CurPos], CurPos);
			TempPItem->CmdDef = &DefaultCDef;
		}
		TempCDef = TempPItem->CmdDef;
		for (TempPos = 0x00; TempPos < TempCDef->Length; TempPos ++)
			FileMask[CurPos + TempPos] |= 0x01;	// mark as "processed"
		
		if (TempCDef->Flags & (CDFLG_JUMP | CDFLG_TRACK_END | CDFLG_LOOP))
			TempPItem->Flags |= PIFLG_BLK_END;
		
		TempPos = 0x0000;
		for (CurCmd = 0x00; CurCmd < TempCDef->ParamCount; CurCmd ++)
		{
			if (TempCDef->Params[CurCmd].Flags & BYTORD_POINTER)
			{
				TempPos = GetParamPointer(CurPos, &TempCDef->Params[CurCmd]);
				if (TempCDef->Flags & CDFLG_SUBROUTINE)
					AddToPointerList(TempPos, SPTR_MODE_SUB, SeqPData);
				else if (TempCDef->Flags & CDFLG_LOOP)
					AddToPointerList(TempPos, SPTR_MODE_LOOP, SeqPData);
				else
					AddToPointerList(TempPos, SPTR_MODE_UNDEF, SeqPData);
				if (! FileMask[TempPos])
				{
					FileMask[TempPos] |= 0x02;	// mark as "pointer noted"
					AddToPQueue(&SeqPData->PQHead, &SeqPData->PQEnd, TempPos);
				}
			}
		}
		
		CurPos += TempCDef->Length;
		if (TempCDef->Flags & CDFLG_TRACK_END)
			break;	// Track End - stop processing
		if (TempCDef->Flags & CDFLG_JUMP)
		{
			if (! TempPos || FileMask[TempPos])
				break;	// Jump to already processed data - stop processing
		}
	}	// end while(CurPos < FileSize)
	
		// Doing that here and not at the beginning of the loop simplifies the "add to queue" code.
		TempPQueue = SeqPData->PQHead;
		SeqPData->PQHead = TempPQueue->next;
		free(TempPQueue);
	}	// end while(SeqPData->PQHead != NULL)
	
	free(FileMask);	FileMask = NULL;
	
	qsort(PItems, PItmCount, sizeof(SEQ_PITEM), &Seq_PItem_Compare);
	
	if (PItmAlloc > PItmCount)
		PItems = (SEQ_PITEM*)realloc(PItems, PItmCount * sizeof(SEQ_PITEM));
	SeqPData->ItemCount = PItmCount;
	SeqPData->Items = PItems;
	return;
}

static void SetSeqDataLabels(SEQ_PDATA* SeqPData)
{
	UINT32 CurPItm;
	SEQ_PITEM* TempPItem;
	PLIST* CurPList;
	UINT8 TrkID;
	UINT8 SubID;
	UINT8 LoopID;
	const SEQ_PITEM* RefTrack;
	const SEQ_PITEM* RefSub;
	
	TrkID = 0x00;
	SubID = 0x00;
	LoopID = 0x00;
	CurPList = SeqPData->PtrListHead;
	while(CurPList != NULL)
	{
		if (CurPList->Mode & SPTR_MODE_TRK)
		{
			CurPList->AddID = TrkID;
			TrkID ++;
			LoopID = 0x00;
		}
		else if (CurPList->Mode & SPTR_MODE_SUB)
		{
			CurPList->AddID = SubID;
			SubID ++;
			LoopID = 0x00;
		}
		else if (CurPList->Mode & SPTR_MODE_LOOP)
		{
			CurPList->AddID = LoopID;
			LoopID ++;
		}
		CurPList = CurPList->next;
	}
	
	RefTrack = RefSub = NULL;
	CurPList = SeqPData->PtrListHead;
	for (CurPItm = 0x00; CurPItm < SeqPData->ItemCount; CurPItm ++)
	{
		if (CurPList == NULL)
			break;
		TempPItem = &SeqPData->Items[CurPItm];
		
		// Note: Make sure that CurPList points to either NULL, or to some pointer that is
		//       < CurPos or, if possible, == CurPos
		while(CurPList != NULL && CurPList->Offset < TempPItem->Pos)
			CurPList = CurPList->next;
		
		if (CurPList != NULL && CurPList->Offset == TempPItem->Pos)
		{
			if (CurPItm)
				SeqPData->Items[CurPItm - 1].Flags |= PIFLG_BLK_END;
			CurPList->DstPItem = TempPItem;
			TempPItem->Flags |= PIFLG_BLK_ST;
			if (CurPList->Mode & SPTR_MODE_TRK)
			{
				TempPItem->LabelName = "Trk";
				TempPItem->LblRef = NULL;
				RefTrack = TempPItem;
				RefSub = NULL;
			}
			else if (CurPList->Mode & SPTR_MODE_SUB)
			{
				TempPItem->LabelName = "Sub";
				TempPItem->LblRef = RefTrack;
				RefSub = TempPItem;
			}
			else if (CurPList->Mode & SPTR_MODE_LOOP)
			{
				TempPItem->LabelName = "Loop";
				TempPItem->LblRef = (RefSub != NULL) ? RefSub : RefTrack;
			}
			if (CurPList->AddID != 0xFF)
				TempPItem->LabelID = CurPList->AddID;
		}
	}
	
	return;
}


static void FlushLineData(LINE_STATE* LState)
{
	if (! LState->StrPos)
		return;
	
	// remove trailing tabs
	while(LState->StrPos && LState->Buffer[LState->StrPos - 1] == '\t')
		LState->StrPos --;
	LState->Buffer[LState->StrPos] = '\0';
	
	fprintf(LState->hFile, "%s\n", LState->Buffer);
	LState->StrPos = 0x00;
	LState->Flags = 0x00;
	LState->ValsOnLine = 0x00;
	
	return;
}

static void Line_EnsureCommand(LINE_STATE* LState, const char* CmdName)
{
	if (LState->StrPos == 0)
	{
		UINT32 ChrPos;
		
		LState->StrPos = sprintf(LState->Buffer, "\t%s\t", CmdName);
		ChrPos = strlen(CmdName) + 1;	// the last tab takes at least 1 space
		ChrPos = (ChrPos + 7) & ~7;
		while(ChrPos < 16)
		{
			LState->Buffer[LState->StrPos] = '\t';
			LState->StrPos ++;
			ChrPos += 8;
		}
		LState->ValsOnLine = 0x00;
	}
	return;
}

static void PrintLabelRecurse(LINE_STATE* LState, const SEQ_PITEM* PItem)
{
	if (PItem->LblRef != NULL)
	{
		PrintLabelRecurse(LState, PItem->LblRef);
		LState->Buffer[LState->StrPos] = '_';	LState->StrPos ++;
	}
	else if (LState->LblBase != NULL)
	{
		LState->StrPos += sprintf(LState->Buffer + LState->StrPos, "%s", LState->LblBase);
		LState->Buffer[LState->StrPos] = '_';	LState->StrPos ++;
	}
	
	if (PItem->LabelID == (UINT32)-1)
		LState->StrPos += sprintf(LState->Buffer + LState->StrPos, "%s", PItem->LabelName);
	else
		LState->StrPos += sprintf(LState->Buffer + LState->StrPos, "%s_%02u", PItem->LabelName, PItem->LabelID);
	
	return;
}

static void PrintLabel(LINE_STATE* LState, const SEQ_PITEM* PItem, UINT16 Offset)
{
	FlushLineData(LState);
	
	PrintLabelRecurse(LState, PItem);
	LState->StrPos += sprintf(LState->Buffer + LState->StrPos, ":\t; %04X", Offset);
	FlushLineData(LState);
	
	return;
}

/*static void PrintLabel(LINE_STATE* LState, const char* String, UINT32 Value, UINT16 Offset)
{
	FlushLineData(LState);
	
	if (Value == (UINT32)-1)
		fprintf(LState->hFile, "%s:\t; %04X\n", String, Offset);
	else
		fprintf(LState->hFile, "%s_%02u:\t; %04X\n", String, Value, Offset);
	
	return;
}*/

static void PrintCommandStr(LINE_STATE* LState, const char* String)
{
	FlushLineData(LState);
	Line_EnsureCommand(LState, String);
	return;
}

static void PrintLineStr(LINE_STATE* LState, const char* String)
{
	Line_EnsureCommand(LState, "db");
	
	if (LState->ValsOnLine)
	{
		LState->Buffer[LState->StrPos] = ',';	LState->StrPos ++;
		LState->Buffer[LState->StrPos] = ' ';	LState->StrPos ++;
	}
	LState->StrPos += sprintf(LState->Buffer + LState->StrPos, "%s", String);
	
	LState->ValsOnLine ++;
	if (LState->ValsOnLine >= 8)
		FlushLineData(LState);
	
	return;
}

static void PrintLineByte(LINE_STATE* LState, UINT8 Value)
{
	Line_EnsureCommand(LState, "db");
	
	if (LState->ValsOnLine)
	{
		LState->Buffer[LState->StrPos] = ',';	LState->StrPos ++;
	}
	if (Value < 0xA0)
		LState->StrPos += sprintf(LState->Buffer + LState->StrPos, " %02Xh", Value);
	else
		LState->StrPos += sprintf(LState->Buffer + LState->StrPos, "0%02Xh", Value);
	
	LState->ValsOnLine ++;
	if (LState->ValsOnLine >= 8)
		FlushLineData(LState);
	
	return;
}

static void PrintLineValue(LINE_STATE* LState, const PARAM_DEF* ParamDef, UINT16 FilePos, const PLIST* SeqPtrList)
{
	PARAM_OP CurVal;
	
	CurVal.Operator = OP_INT;
	if (ParamDef->Flags & BYTORD_POINTER)
	{
		CurVal.ValInt = GetParamPointer(FilePos, ParamDef);	// already executes DoOperators
	}
	else
	{
		CurVal.ValInt = GetParamValue(FilePos, ParamDef);
		DoOperators(&CurVal, ParamDef->OperatorCount, ParamDef->Operators);
	}
	Line_EnsureCommand(LState, "db");
	
	if (LState->ValsOnLine)
	{
		LState->Buffer[LState->StrPos] = ',';	LState->StrPos ++;
		LState->Buffer[LState->StrPos] = ' ';	LState->StrPos ++;
	}
	
	if (ParamDef->Flags & BYTORD_POINTER)
	{
		const PLIST* CurPLst;
		
		CurPLst = SeqPtrList;
		while(CurPLst != NULL && CurPLst->Offset < CurVal.ValInt)
			CurPLst = CurPLst->next;
		if (CurPLst != NULL && CurPLst->Offset == CurVal.ValInt)
			PrintLabelRecurse(LState, CurPLst->DstPItem);
		else
			LState->StrPos += sprintf(LState->Buffer + LState->StrPos, "ofs_%04X", CurVal.ValInt);
	}
	else if (ParamDef->Flags & BYTORD_NOTE)
	{
		const char* NOTE_NAME[0x0F] = {"Rst", "C", "Cs", "D", "Eb", "E", "F", "Fs", "G", "Gs", "A", "Bb", "B", "C1", "Hold"};
		LState->StrPos += sprintf(LState->Buffer + LState->StrPos, "n%s", NOTE_NAME[CurVal.ValInt]);
	}
	else if (ParamDef->Flags & BYTORD_DELAY)
	{
	//	const UINT8 LEN_TICKS[0x0D] =
	//	{	192, 96, 48, 24, 12, 6, 3,
	//			 64, 32, 16,  8, 4, 2};
		const UINT8 LEN_VALS[0x0D] =
		{	  1,  2,  4,  8, 16, 32, 64,
				  3,  6, 12, 24, 48, 96};
		if (CurVal.ValInt < 0x0D)
			LState->StrPos += sprintf(LState->Buffer + LState->StrPos, "%u", LEN_VALS[CurVal.ValInt]);
		else
			LState->StrPos += sprintf(LState->Buffer + LState->StrPos, "%s", "lExtra");
	}
	else if (CurVal.Operator & OP_FLOAT)
	{
		LState->StrPos += sprintf(LState->Buffer + LState->StrPos, "%f", CurVal.ValFloat);
	}
	else
	{
		if (ParamDef->Flags & BYTORD_HEX)
		{
			if (CurVal.ValInt < 0xA0)
				LState->StrPos += sprintf(LState->Buffer + LState->StrPos, "%02Xh", CurVal.ValInt);
			else
				LState->StrPos += sprintf(LState->Buffer + LState->StrPos, "0%02Xh", CurVal.ValInt);
		}
		else
		{
			LState->StrPos += sprintf(LState->Buffer + LState->StrPos, "%d", CurVal.ValInt);
		}
	}
	
	LState->ValsOnLine ++;
	if (LState->ValsOnLine >= 8)
		FlushLineData(LState);
	
	return;
}

static void PrintSeqData(SEQ_PDATA* SeqPData, FILE* hFile, const char* BaseLbl)
{
	LINE_STATE LineState;
	SEQ_PITEM EndPItm;
	UINT16 CurPos;
	UINT32 CurPItm;
	SEQ_PITEM* TempPItem;
	CMD_DEF* TempCDef;
	UINT8 CurParam;
	
	LineState.hFile = hFile;
	memset(LineState.Buffer, 0x00, 0x200);
	LineState.LblBase = BaseLbl;
	LineState.StrPos = 0x00;
	LineState.Flags = 0x00;
	EndPItm.Pos = -1;
	
	if (LineState.LblBase != NULL)
		fprintf(hFile, "%s:\n", LineState.LblBase);
	fprintf(hFile, "\tStartSongMarker\n");
	CurPos = 0x0000;
	CurPItm = 0x00;
	TempPItem = &SeqPData->Items[CurPItm];
	while(CurPos < FileSize)
	{
		if (CurPos < TempPItem->Pos)
		{
			PrintLineByte(&LineState, FileData[CurPos]);
			CurPos ++;
		}
		else if (CurPos == TempPItem->Pos)
		{
			//FlushLineData(&LineState);
			//fprintf(hFile, "; Item %u, Offset %04X\n", CurPItm, CurPos);
			if (TempPItem->LabelName != NULL)
				//PrintLabel(&LineState, TempPItem->LabelName, TempPItem->LabelID, CurPos);
				PrintLabel(&LineState, TempPItem, CurPos);
			
			TempCDef = TempPItem->CmdDef;
			if (TempCDef->Flags & CDFLG_INLINE)
			{
				if (*TempCDef->Name != '\0')
					PrintLineStr(&LineState, TempCDef->Name);
				for (CurParam = 0x00; CurParam < TempCDef->ParamCount; CurParam ++)
					PrintLineValue(&LineState, &TempCDef->Params[CurParam], CurPos, SeqPData->PtrListHead);
			}
			else
			{
				PrintCommandStr(&LineState, TempCDef->Name);
				for (CurParam = 0x00; CurParam < TempCDef->ParamCount; CurParam ++)
					PrintLineValue(&LineState, &TempCDef->Params[CurParam], CurPos, SeqPData->PtrListHead);
				FlushLineData(&LineState);
			}
			
			if (TempPItem->Flags & PIFLG_BLK_END)
				fputc('\n', LineState.hFile);
			
			CurPos += TempCDef->Length;
		}
		else
		{
			FlushLineData(&LineState);
			fprintf(hFile, "; Warning - Item %u, Offset %04X\n", CurPItm, CurPos);
		}
		if (CurPos > TempPItem->Pos)
		{
			CurPItm ++;
			if (CurPItm < SeqPData->ItemCount)
				TempPItem = &SeqPData->Items[CurPItm];
			else
				TempPItem = &EndPItm;
		}
		while(CurPos > TempPItem->Pos)
		{
			CurPItm ++;
			if (CurPItm < SeqPData->ItemCount)
				TempPItem = &SeqPData->Items[CurPItm];
			else
				TempPItem = &EndPItm;
		}
	}
	FlushLineData(&LineState);
	
	return;
}

static void FreeSeqData(SEQ_PDATA* SeqPData)
{
	PLIST* CurPLst;
	PLIST* LastPLst;
	PQUEUE* CurPQueue;
	PQUEUE* LastPQueue;
	
	CurPLst = SeqPData->PtrListHead;
	while(CurPLst != NULL)
	{
		LastPLst = CurPLst;
		CurPLst = CurPLst->next;
		free(LastPLst);
	}
	SeqPData->PtrListHead = NULL;
	
	CurPQueue = SeqPData->PQHead;
	while(CurPQueue != NULL)
	{
		LastPQueue = CurPQueue;
		CurPQueue = CurPQueue->next;
		free(LastPQueue);
	}
	SeqPData->PQHead = NULL;
	SeqPData->PQEnd = NULL;
	
	SeqPData->ItemCount = 0x00;
	free(SeqPData->Items);	SeqPData->Items = NULL;
	
	return;
}

UINT8 LoadSeqData(const char* FileName)
{
	FILE* hFile;
	
	hFile = fopen(FileName, "rb");
	if (hFile == NULL)
		return 0xFF;
	
	fseek(hFile, 0x00, SEEK_END);
	FileSize = ftell(hFile);
	
	fseek(hFile, 0x00, SEEK_SET);
	FileData = (UINT8*)malloc(FileSize);
	fread(FileData, 0x01, FileSize, hFile);
	
	fclose(hFile);
	
	return 0x00;
}

void ConvertMusic(const char* FileTitle, const SEQ_DEF* SeqDef)
{
	char FileName[0x100];
	char* FileNTitle;
	char* FileExt;
	UINT8 RetVal;
	SEQ_PDATA SeqParseData;
	FILE* hFile;
	
	strcpy(FileName, FILE_PATH);
	FileNTitle = FileName + strlen(FileName);
	strcpy(FileNTitle, FileTitle);
	FileExt = strrchr(FileNTitle, '.');
	if (FileExt == NULL)
		FileExt = FileNTitle + strlen(FileNTitle);
	
	RetVal = LoadSeqData(FileName);
	if (RetVal)
	{
		printf("Error opening %s!\n", FileNTitle);
		return;
	}
	
	printf("Parsing Sequence Data ...\n");
	memset(&SeqParseData, 0x00, sizeof(SEQ_PDATA));
	/*{
		UINT16 CurOfs;
		
		CurOfs = (FileData[0x00] << 0) | (FileData[0x01] << 8);
		AddToPQueue(&SeqParseData.PQHead, &SeqParseData.PQEnd, CurOfs);
		CurOfs = (FileData[0x02] << 0) | (FileData[0x03] << 8);
		AddToPQueue(&SeqParseData.PQHead, &SeqParseData.PQEnd, CurOfs);
		CurOfs = (FileData[0x04] << 0) | (FileData[0x05] << 8);
		AddToPQueue(&SeqParseData.PQHead, &SeqParseData.PQEnd, CurOfs);
		CurOfs = (FileData[0x06] << 0) | (FileData[0x07] << 8);
		AddToPQueue(&SeqParseData.PQHead, &SeqParseData.PQEnd, CurOfs);
	}*/
	ParseSeqData(SeqDef, &SeqParseData);
	SetSeqDataLabels(&SeqParseData);
	
	strcpy(FileExt, ".asm");
	hFile = fopen(FileName, "wt");
	if (hFile == NULL)
	{
		printf("Error opening %s!\n", FileNTitle);
		goto FreeAndFinish;
	}
	
	printf("Printing Sequence Text ...\n");
	//PrintSeqData(&SeqParseData, hFile, NULL);
	{
		*FileExt = '\0';
		PrintSeqData(&SeqParseData, hFile, FileNTitle);
	}
	fclose(hFile);
	
FreeAndFinish:
	FreeSeqData(&SeqParseData);
	FileSize = 0x00;
	free(FileData);	FileData = NULL;
	return;
}

int main(int argc, char* argv[])
{
	SEQ_DEF CurSeqDef;
	HANDLE hFndFile;
	WIN32_FIND_DATA FndData;
	
	printf("Loading Definition File ...\n");
	InitOperatorParsing();
	LoadDefinitionFile(FILE_PATH "S1_Cmds.txt", &CurSeqDef);
	
	hFndFile = FindFirstFile(FILE_PATH "/Mus*.bin", &FndData);
	if (hFndFile == INVALID_HANDLE_VALUE)
		return 2;
	
	do
	{
		printf("%s: ", FndData.cFileName);
		ConvertMusic(FndData.cFileName, &CurSeqDef);
	} while(FindNextFile(hFndFile, &FndData));
	FindClose(hFndFile);
	
	
	
	printf("Done.\n");
	//_getch();
	return 0;
}
