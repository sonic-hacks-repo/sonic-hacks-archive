******Sonic 2 Remixed v0.01 by Ravenfreak******
Special thanks to Glitch for disassembling Sonic 2, and for his guide on how
to relocate player logic. (Which i've used obviously :V)
Things done so far:
Changed the life counter so it can hold up to 99 lives
Added new monitors:
Clock Monitor- Resets the timer
! Monitor- Resets the Ring Counter
? Monitor- Gives Sonic 10 rings
Bubble Monitor- Allows Sonic to breath underwater for an unlimited amount of time 
Added a WIP bounce attack
New art (very WIP, until I can find an artist. PM me if you'd like to help.)
New object layout (in some levels) 
Edited Crabmeat's logic, so it moves slightly faster
Known Bug:
The added WIP bounce attack messes with Sonic's h/v velocity in the air, as well as
messes with skidding and rolling due to editing the velocity for the move to work. 
