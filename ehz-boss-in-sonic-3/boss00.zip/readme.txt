boss00.asm is the source code. Run compile.bat to make it into BOSS00.BIN (machine code).
Copy the data from BOSS00.BIN into S3&K.BIN at the location 400F2C.

Play the game and use S3&K.GS0 save state to get directly to the boss.

Remember this work is copyrighted.

/LOst