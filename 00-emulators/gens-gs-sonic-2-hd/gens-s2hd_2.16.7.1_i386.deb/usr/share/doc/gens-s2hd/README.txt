Gens/GS r7 S2HD Edition

Copyright (c) 1999-2002 by Stéphane Dallongeville
Copyright (c) 2003-2004 by Stéphane Akhoun
Copyright (c) 2008-2009 by David Korth

This version of Gens is maintained by David Korth.
E-mail: gerbilsoft@verizon.net

For news on Gens/GS, visit Sonic Retro:
http://www.sonicretro.org

================================================================

1. What is Gens/GS?

Gens/GS r7 is David Korth's fork of Gens, initially based on
Gens for Linux v2.15.5. The number after the "r" indicates the
Gens/GS release. Releases are usually made after a significant new
feature has been added, with minor releases if a major bug is found.

================================================================

2. Gens/GS r7 S2HD Edition

This is a special edition of Gens/GS. It is designed to run the classic
Sega Genesis game "Sonic the Hedgehog 2" (and "Knuckles the Echidna in
Sonic the Hedgehog 2") in High Definition.

Features in Gens/GS r7 S2HD Edition:
- High-definition graphics!
- Five different HD modes: 480i, 480p, 720p, 1080i, 1080p.
- Optional HD Realism Filter and Lens Flare effects. (Provided by Sonic65.)
- Audio Reverb.

Minimum System Requirements:
- Dual-core Intel Core Duo, 2.00 GHz
- 1 GB RAM
- ATI or nVidia video card with 256 MB video memory.
- Pixel Shader 2.0
- HDTV capable of 720p

Recommended System Requirements:
- Quad-core Intel Core i7, 2.00 GHz
- 2 GB RAM
- ATI or nVidia video card with 512 MB video memory.
- Pixel Shader 2.0
- HDTV capable of 1080p

NOTE: SMW Central users will need to copy cmd.exe into the Gens/GS r7
S2HD Edition directory before running gens_S2HD.exe.

================================================================

3. Other ROMs

Gens/GS r7 S2HD Edition does not support ROM images other than "Sonic the
Hedgehog 2" and "Knuckles the Echidna in Sonic the Hedgehog 2". If you
would like to load a different ROM image, please download the regular version
of Gens/GS at http://info.sonicretro.org/Gens/GS .
