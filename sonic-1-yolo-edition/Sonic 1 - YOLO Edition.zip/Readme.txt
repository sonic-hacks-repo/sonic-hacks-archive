Thank you for downloading Sonic 1 - YOLO Edition.

In order to play this Hack. You need Sega Genesis Emulator, Sonic The Hedgehog 1 Rom File, and Lunar IPS Software.

All you got to do is open Lunar IPS Software and apply a Patch to Rom. Then open Emulator and run a Rom.

Good luck!