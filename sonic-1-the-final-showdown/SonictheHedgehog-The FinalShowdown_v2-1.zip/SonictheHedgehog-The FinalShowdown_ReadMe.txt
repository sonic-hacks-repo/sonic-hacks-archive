Sonic the Hedgehog - The Final Showdown

Credits: Anthall (Main), Tweaker & SOTI & Nineko (Bubble monitor), Afti & Metal Man88 & ColinC10 & HighFrictionZone (advice & opnions), Esrael (level editing tools), and Hivebrain (created a dissasembly)


Sonic the Hedgehog - The Final Showdown is a hack of Sonic the Hedgehog for the Sega Mega Drive/Genesis.

==Story==
After the battle of Sonic the Hedgehog and Dr Ivo Robotnik at the end of Sonic the Hedgehog, Dr Robotnik promised to remove all his badniks from Mobius. Robotnik was doing as he had promised, or so Sonic thought...

Dr Robotnik was secretly double crossing Sonic. He was secretly torturing all of Sonic's friends and was sending meteorites to the planet. Dr Robotnik then went to attempt to steal the Master Emerald from Knuckles.

On Robotnik's confrontation with Knuckles, they started to battle. Knuckles tried to fight Dr Robotnik but was sorely defeated and was left for dead as Dr Robotnik stole the Master Emerald.

When Sonic found out about Dr Robotnik's double crossing, he severed his new found friendship with Dr Robotnik and went to the Master Emerald. He saw Knuckles dying and Knuckles' last words were: "Sonic...Please get the Master Emerald back and save all of mankind.". Knuckles passed away. Sonic was furious and upset. After crying for a bit, Sonic stood up and lifted his fist in the air and shouted "I will kill Dr Robotnik:

In the Final Showdown."

==Features==

*Unique looking Spin Dash implemented.
*Spike damage behavior changed to that of Sonic 2.
*New level layouts, palettes and monitors.
*Dr Robotnik's ships are stronger.
*Rearranged level music order. 
*New artwork for some monitors.
*Two new monitors. One that gives 50 rings (very rare) and one that replenishes Sonic's air supply in underwater sections.

==History==

===Sonic Gets Poisoned!===

He started this hack which was first called Sonic Gets Poisoned!. It had all original levels and palette changes. However, it was met with much criticism from members of Sonic Retro due to the amount of glitches and the clashing colour scheme used in the hack.

===Sonic the Hedgehog 2008 Beta 2.0===

The second release of Sonic Gets Poisoned! was called Sonic the Hedgehog 2008. It was far less buggy, and had some more alternate routes and half-decent colors. Sonic's blue color was restored (which is why the name was changed). The response from the Sonic Retro members was far better this time, due to the better palettes and the reduction of glitches.

===Sonic the Hedgehog - The Final Showdown v2.1===

This version was released to allow a wiki page to be created for it, because all the earlier versions didn't meet the Hack Policy. It is the first time Anthall has done ASM and graphics editing. He has has created some new monitor types. He has also made Techra City Zone 3 much longer.