=============================================================================
************ SONIC 1: PAINTO EDITION 2 - VERSION 3.0 INFORMATION ************
=============================================================================
Sonic the Hedgehog 1: Painto edition 2 or simpler Sonic: Painto edtion 2 is a modificaton of Sonic the Hedgehog (1991) game and the first part of my "Paintofitization" project. It contains a lot of features. It have 2 in name because is second attempt to make PE of S1.

This version is a total change compared to previous versions.

Below you can find the information about new things and some other stuff.

=============================================================================
********************************** ZONES ************************************
=============================================================================
In this version there are 3 playable zones:

|||||||||||||||||||||||||||| GREEN GARDEN ZONE ||||||||||||||||||||||||||||||

Just another Green Hill-esque zone. All 4 acts of the Zone are playable. Zone was initially meant to be a port of Azure Lake Zone from Sonic 3, but due to lack of knowledge the zone's art is totally custom. Boss fight is pretty like in previous version, but the exact fight from 2.0 is used as pinch mode.

||||||||||||||||||||||||||||||| BRIDGE ZONE |||||||||||||||||||||||||||||||||

This one is from 2.0 version. The differences are acts 3 & 4, for which I did new layouts. All 4 acts of the Zone are playable. My biggest and best new thing in 3.0's Bridge is definetely the boss. I will don't tell how looks the fight, just see it by yourselves.

||||||||||||||||||||||||||||| CHEESE CAVE ZONE ||||||||||||||||||||||||||||||

The last playable zone is Cheese Cave Zone from 2.0. Only first act is playable, but it's because I spent the longest time on making it. All the act is based on puzzles with buttons, dodging enemies and getting air. Almost all of the areas are underwater. No boss there.

=============================================================================
****************************** SPECIAL STAGES *******************************
=============================================================================
There are 3 edited Special Stages and 3 unedited. Each Special Stage have his own music.

First stage is from 2.0, so you know how it looks.

The second one is pretty short. You start in a corridor then you need to break blocks to get into a big room with emerald in center of breakable blocks.

The third one is the longest. There are 9 big rooms which are connected one with another leading to the room with emerald. There are also 2 bonus rooms, where are GOAL blocks and 1-ups. Tip: the closer to emerald you are the in exits from rooms are stronger.

=============================================================================
****************************** OTHER FEATURES *******************************
=============================================================================

||||||||||||||||||||||||||||| SOUND TEST MENU |||||||||||||||||||||||||||||||

In 3.0 version there appears a totally new Sound Test menu. All songs are decribe according to this template:

Upper lone: Song Usage (name).
Bottom line: If song is ported, there's it's origin.

The controls are:
*Left/Right arrow buttons - change song,
*A button - Jump $10 (#16) songs,
*B/C buttons - play song,
*Start button - exit from menu.

|||||||||||||||||||||||||||| SPECIAL STAGE RINGS ||||||||||||||||||||||||||||

The Special Stage Rings, now are working like in S3&K, but of course it isn't perfect port. There is one ring per act, so you have 9 oportunities to get emeralds (and you can fail 3 times). They also act as checkpoint. I'm not giving any tips for it's locations - search them by yourselves.

||||||||||||||||||||||||||||| LEVEL SELECT MENU |||||||||||||||||||||||||||||

Basically is nothing special, but it allows you to select one of playable acts. To access it, play 4 songs in the Sound Test in correct order.

Tip: It's on my SSRG profile.

=============================================================================
******************************* KNOWN ISSUES ********************************
=============================================================================
*When Special Stage Ring appears on screen and you don't go to special stage, the art will be glitched.
*Sometimes in Special Stage the art can dissapear in certain areas (I guess is VRAM).
*After the music fades out, new sound effects won't play (althrough the ones played right before fading out will work).

=============================================================================
********************************** CREDITS **********************************
=============================================================================
Here is the list of persons and places which helped me during hack creating:
*SSRG forums
  - Selbi (Button presses, SRAM),
  - GF64 (demo recording, custom BG in S1 levsel - the code is used in various screens),
  - others that I forgot.
*Sonic Retro forums & wiki
  - SCHG How-tos.
*Art
  - Spriters Resource (texts),
  - Some Guys I Forgot - Frontal Robotnik art,
  - Shockwave ("4" number in title cards).
*Beta testing
  - NeoFusionBox & EditChris (layouts, object placement),
  - LuigiXHero (testing hack on Regen).
*Various fixes and hardware compatibility
  - Clownacy.
*Other things
  - nineko (Bridge Zone music),
  - ValleyBell (SMPS Converter which was used to port S3&K songs),
  - Esrael (Sonic 2 Level Select),
  - Sonic Team (creating Sonic 1 & 2 code and art),
  - Hivebrain (Sonic 1 disassembly).
*Other I forgot
=============================================================================
**************************** QUESTIONS & ANSWERS ****************************
=============================================================================
Q: Is The Main Zone and hubs system cancelled?
A: No, it isn't. They will appear in Adventure Mode, but in this version it isn't featured.

Q: Will you add Jungle Zone in next release?
A: No.

Q: Will you cancel this project and start "Sonic 2: Painto Edition 3"?
A: No.

Q: Why I can't select other zones in level select?
A: Because they aren't playable.

Q; Why I can't select Adventure Mode?
A: I don't see sense of making Adventure Mode with only 2 zones and 1 act of the third.

Q: When you will add Adventure Mode as playable?
A: When I will finish at least 5 zones, so this means that when I will finish Cheese Cave and Marble edit or Casino Madness.

||||||||||||||||||||||||||||| THANKS FOR READING ||||||||||||||||||||||||||||
=============================================================================
******* SONIC 1: PAINTO EDITION 2 by Painto maniak - 6th October 2014 *******
=============================================================================