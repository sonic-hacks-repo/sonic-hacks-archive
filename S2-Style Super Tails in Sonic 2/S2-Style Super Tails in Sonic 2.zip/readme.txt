This is a hack of Sonic the Hedgehog 2, by Clownacy, which gives Tails a Super transformation, much like that of Sonic.

This is not Sonic 3 & Knuckles' Super Tails: he does not have Flickies; he does not fly. This is simply an equivalent of Super Sonic. This is a recreation of what Super Tails would have been like if Sonic Team had actually added him during Sonic 2's development.

That said, if you complain at the lack of either of the above, you're a fucking idiot.
