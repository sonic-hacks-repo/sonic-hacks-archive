Sonic 1 Reversed Frequencies

Credits:FraGag

This is a hack which changes the frequencies of music and sound effects. It makes for a different gameplay experience.